package StepDefinitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminTestBooking {

	WebDriver driver=null;
	
	@Given("admin1 browser is open")
	public void admin1_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("admin1 is on login page")
	public void admin1_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/admin");
		
	}

	@When("admin1 enters username and password")
	public void admin1_enters_username_and_password() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		Thread.sleep(2000);
		
	}

	@And("admin1 clicks on login")
	public void admin1_clicks_on_login() {

		driver.findElement(By.xpath("//button[@type=\'submit\' and @class=\'btn btn-primary btn-block ladda-button fadeIn animated mdc-ripple-upgraded\']")).click();
		
	}

	@Then("admin1 is navigated to dashboard")
	public void admin1_is_navigated_to_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
		
	}

	@Then("admin1 clicks on Paid Bookings")
	public void admin1_clicks_on_paid_bookings() {
	    
		driver.findElement(By.xpath("//div[text()=\'Paid Bookings\']")).click();
		
	}

	@When("admin1 clicks on Invoice")
	public void admin1_clicks_on_invoice() throws InterruptedException {
		
	/*	JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement previousbtn=driver.findElement(By.xpath("//a[@class=\'paginate_button current\']"));
		js.executeScript("arguments[0].scrollIntoView();", previousbtn);
	*/	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		
		//driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/api/../hotels/booking/invoice/8027/2\']")).click();
		driver.findElement(By.xpath("/html/body/div[2]/div[2]/main/div/div[2]/div/div/div[2]/div/table/tbody/tr[1]/td[14]/a")).click();
		
		//driver.close();
		//driver.quit();
		
	}

	@Then("admin1 is navigated to invoice")
	public void admin1_is_navigated_to_invoice() throws InterruptedException {
		
		ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		driver.findElement(By.xpath("//h3[@class=\'title\']")).isDisplayed();
		Thread.sleep(2000);
		
		driver.close();
		driver.switchTo().window(tabs.get(0));
		Thread.sleep(2000);
		driver.quit();	
		
		
	}
	
}
