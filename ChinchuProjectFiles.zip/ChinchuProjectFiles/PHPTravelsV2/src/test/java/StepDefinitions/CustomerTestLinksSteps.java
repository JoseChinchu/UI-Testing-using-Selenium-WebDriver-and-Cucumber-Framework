package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerTestLinksSteps {

	WebDriver driver=null;
	
	@Given("browser is opened")                  
	public void browser_is_opened() {
	
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("user is on the login page")
	public void user_is_on_the_login_page() {
		
		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("user enter username and password")
	public void user_enter_username_and_password() {
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demouser");
				
	}
	
	@And("user clicks on login button")
	public void user_clicks_on_login_button() {
		
		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}
	
	@Then("user navigated to home page")
	public void user_navigated_to_home_page() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		//Thread.sleep(2000);
		//driver.close();
		//driver.quit();
	}
	
	@Then("user clicks on My Bookings")
	public void user_clicks_on_my_bookings() {
		
		//driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/bookings\' and @class=\'dropdown-item waves-effect\']")).click();
		driver.findElement(By.xpath("//*[@id=\'fadein\']/div[4]/div/div[3]/ul/li[2]/a")).click();
	
	}

	@Then("user clicks on Add Funds")
	public void user_clicks_on_add_funds() {

		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/add_funds\' and @class=\' waves-effect\']")).click();
	
	}

	@Then("user clicks on My Profile")
	public void user_clicks_on_my_profile() {
	    
		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/profile\' and @class=\' waves-effect\']")).click();
	
	}

	@Then("user clicks on logout")
	public void user_clicks_on_logout() {
	    
		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/logout\' and @class=\' waves-effect\']")).click();
		driver.close();
		driver.quit();
		
	}

}
