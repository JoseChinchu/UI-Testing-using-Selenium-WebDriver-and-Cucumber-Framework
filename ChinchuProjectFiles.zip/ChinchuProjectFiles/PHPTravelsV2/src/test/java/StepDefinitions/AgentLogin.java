package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentLogin {

	WebDriver driver=null;
	
	@Given("agent browser is open")
	public void agent_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("agent is on login page")
	public void agent_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("agent enters agent@phptravels.com and demoagent")
	public void agent_enters_agent_phptravels_com_and_demoagent() throws InterruptedException {
	    
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoagent");
		Thread.sleep(2000);
		
	}

	@When("agent clicks on login")
	public void agent_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}

	@Then("agent is navigated to home page")
	public void agent_is_navigated_to_home_page() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("agent enters agent@phptravels.com and abc1")
	public void agent_enters_agent_phptravels_com_and_abc1() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("abc1");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("agent enters agent and demoagent")
	public void agent_enters_agent_and_demoagent() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("agent");
		driver.findElement(By.name("password")).sendKeys("demoagent");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("agent enters {int} and abc")
	public void agent_enters_and_abc(Integer int1) throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("123");
		driver.findElement(By.name("password")).sendKeys("demoagent");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	
}
