package StepDefinitions;

import java.awt.Point;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerPaypalPaymentSteps {

	WebDriver driver=null;
	
	@Given("Browser opened")
	public void browser_opened() {
		
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	}

	@And("user1 is on the login page")
	public void user1_is_on_the_login_page() {
		
		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("user1 enter username and password")
	public void user1_enter_username_and_password() {
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demouser");
		
	}

	@When("user1 clicks on login button")
	public void user1_clicks_on_login_button() {
		
		driver.findElement(By.xpath("//span[text()='Login']")).click();
		
	}

	@Then("user1 navigated to home page")
	public void user1_navigated_to_home_page() {
		
		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		
	}

	@Then("user1 clicks on Add Funds")
	public void user1_clicks_on_add_funds() {
		
		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/add_funds\' and @class=\' waves-effect\']")).click();
		
	}

	@Then("select pay with paypal payment method")
	public void select_pay_with_paypal_payment_method() throws InterruptedException {
	

		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement element=driver.findElement(By.id("gateway_paypal"));
		js.executeScript("arguments[0].scrollIntoView();", element);
		Thread.sleep(2000);
		driver.findElement(By.id("gateway_paypal")).click();
		//Thread.sleep(2000);
	}	
		
	@Then("click on Pay Now")
	public void click_on_pay_now() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\'fadein\']/section[1]/div/div[2]/div/div[1]/div/div/div[2]/form/div/div[2]/div/button")).click();
		Thread.sleep(2000);
		//driver.close();
		//driver.quit();
	}
	
	@Then("user1 is navigated to payment page")
	public void user1_is_navigated_to_payment_page() throws InterruptedException {
		
		driver.findElement(By.xpath("/html/body/div/div[1]/div[1]/small/strong")).isDisplayed();
		//*[@id="buttons-container"]/div/div/div/div[1]
		Thread.sleep(1000);
		driver.close();
		driver.quit();
	}
	
}
