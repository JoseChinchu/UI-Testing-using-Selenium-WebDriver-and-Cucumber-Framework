package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminLogin {

	WebDriver driver=null;
	
	@Given("admin browser is open")
	public void admin_browser_is_open() {
		
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
	}

	@And("admin is on login page")
	public void admin_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/admin");
		
	}

	@When("admin enters admin@phptravels.com and demoadmin")
	public void admin_enters_admin_phptravels_com_and_demoadmin() throws InterruptedException {
	    
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		Thread.sleep(2000);
		
	}
	
	@When("admin clicks on login")
	public void admin_clicks_on_login() {

		driver.findElement(By.xpath("//button[@type=\'submit\' and @class=\'btn btn-primary btn-block ladda-button fadeIn animated mdc-ripple-upgraded\']")).click();
		//driver.switchTo().alert().accept();
	}

	@Then("admin is navigated to home page")
	public void admin_is_navigated_to_home_page() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
	}
	
	@When("admin enters admin@phptravels.com and abc1")
	public void admin_enters_admin_phptravels_com_and_abc1() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("abc1");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("admin enters admin and demoadmin")
	public void admin_enters_admin_and_demoadmin() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("admin enters {int} and abc")
	public void admin_enters_and_abc(Integer int1) throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("123");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

}

