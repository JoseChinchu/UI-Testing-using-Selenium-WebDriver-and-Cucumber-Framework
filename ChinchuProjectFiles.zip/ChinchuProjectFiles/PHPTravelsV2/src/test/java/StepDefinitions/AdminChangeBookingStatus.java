package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminChangeBookingStatus {

	WebDriver driver=null;
	
	@Given("admin3 browser is open")
	public void admin3_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("admin3 is on login page")
	public void admin3_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/admin");
		
	}

	@When("admin3 enters username and password")
	public void admin3_enters_username_and_password() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		Thread.sleep(2000);
		
	}

	@And("admin3 clicks on login")
	public void admin3_clicks_on_login() {

		driver.findElement(By.xpath("//button[@type=\'submit\' and @class=\'btn btn-primary btn-block ladda-button fadeIn animated mdc-ripple-upgraded\']")).click();
		
	}

	@Then("admin3 is navigated to dashboard")
	public void admin3_is_navigated_to_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
		
	}

	@Then("admin3 clicks on Pending Bookings")
	public void admin3_clicks_on_pending_bookings() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Pending Bookings\']")).click();
		Thread.sleep(1000);
	}

	@Then("admin3 clicks on Booking status button and select confirmed status")
	public void admin3_clicks_on_booking_status_button_and_select_confirmed_status() throws InterruptedException {

		Select se=new Select(driver.findElement(By.id("booking_status")));
	    se.selectByVisibleText("Confirmed");
	    Thread.sleep(2000);
		
	}

	@Then("admin3 clicks on Confirmed booking and verify count")
	public void admin3_clicks_on_confirmed_booking_and_verify_count() throws InterruptedException {
		
		driver.findElement(By.xpath("//div[text()=\'Dashboard\']")).click();
		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		driver.findElement(By.xpath("//div[text()=\'Confrimed Bookings\']")).click();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
	}
	
}
