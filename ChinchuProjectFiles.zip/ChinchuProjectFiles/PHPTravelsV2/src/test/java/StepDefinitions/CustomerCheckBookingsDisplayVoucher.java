package StepDefinitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.zeromq.ZStar.Set;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerCheckBookingsDisplayVoucher {

	WebDriver driver=null;
	
	@Given("Browser opened by user2")
	public void browser_opened_by_user2() {
	    
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("user2 is on the login page")
	public void user2_is_on_the_login_page() {
		
		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("user2 enter username and password")
	public void user2_enter_username_and_password() {
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demouser");
		
	}

	@When("user2 clicks on login button")
	public void user2_clicks_on_login_button() {
		
		driver.findElement(By.xpath("//span[text()='Login']")).click();
		
	}

	@Then("user2 navigated to home page")
	public void user2_navigated_to_home_page() {
		
		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		
	}

	@Then("user2 clicks on My Bookings")
	public void user2_clicks_on_my_bookings() throws InterruptedException {
		
		driver.findElement(By.xpath("//*[@id=\'fadein\']/div[4]/div/div[3]/ul/li[2]/a")).click();
		Thread.sleep(2000);
		
	}

	@Then("click on View voucher")
	public void click_on_view_voucher() {
	    
		driver.findElement(By.xpath("/html/body/section[1]/div/div[2]/div/div[1]/div/div/div[2]/div/table/tbody/tr/td[4]/div/a")).click();
	
	}

	@Then("user2 is navigated to Booking Invoice display")
	public void user2_is_navigated_to_booking_invoice_display() throws InterruptedException {
		
		ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		driver.findElement(By.xpath("/html/body/section[1]/div/div/div/div/div[2]/div[1]/h3")).isDisplayed();
		Thread.sleep(2000);
		
		driver.close();
		driver.switchTo().window(tabs.get(0));
		Thread.sleep(2000);
		driver.quit();	
		
	}
	
}
