package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentTestLinks {

	WebDriver driver=null;
	
	@Given("agent1 browser is open")
	public void agent1_browser_is_open() {
		
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("agent1 is on login page")
	public void agent1_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("agent1 enters username and password")
	public void agent1_enters_username_and_password() {

		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoagent");
			
	}

	@When("agent1 clicks on login")
	public void agent1_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}

	@Then("agent1 is navigated to home page")
	public void agent1_is_navigated_to_home_page() throws InterruptedException {

		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		Thread.sleep(2000);
				
	}

	@Then("agent1 clicks on My Bookings")
	public void agent1_clicks_on_my_bookings() {
		
		driver.findElement(By.xpath("/html/body/div[4]/div/div[3]/ul/li[2]/a")).click();
		
	}

	@Then("agent1 clicks on Add Funds")
	public void agent1_clicks_on_add_funds() {

		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/add_funds\' and @class=\' waves-effect\']")).click();
	
	}

	@Then("agent1 clicks on My Profile")
	public void agent1_clicks_on_my_profile() {
		
		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/profile\' and @class=\' waves-effect\']")).click();
				
	}

	@Then("agent1 clicks on Logout")
	public void agent1_clicks_on_logout() {

		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/logout\' and @class=\' waves-effect\']")).click();
		driver.close();
		driver.quit();
				
	}
	
}
