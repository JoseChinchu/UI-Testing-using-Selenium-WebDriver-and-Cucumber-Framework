package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierTestRevenueBreakdownDisplay {

	WebDriver driver=null;
	
	@Given("supplier2 browser is open")
	public void supplier2_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("supplier2 is on login page")
	public void supplier2_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/supplier");
		
	}

	@When("supplier2 enters username and password")
	public void supplier2_enters_username_and_password() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demosupplier");
		Thread.sleep(2000);
		
	}

	@And("supplier2 clicks on login")
	public void supplier2_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()=\'Login\']")).click();
		
	}

	@Then("supplier2 is navigated to dashboard")
	public void supplier2_is_navigated_to_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
				
	}

	@Then("supplier2 check the revenue breakdown display")
	public void supplier2_check_the_revenue_breakdown_display() throws InterruptedException {

		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//h2[text()=\'Revenue Breakdown 2023\']")).isDisplayed();
		driver.close();
		driver.quit();
		
	}
	
}
