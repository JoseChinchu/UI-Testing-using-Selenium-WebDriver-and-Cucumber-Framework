package StepDefinitions;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentSearch {

	WebDriver driver=null;
	
	@Given("agent3 browser is open")
	public void agent3_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("agent3 is on login page")
	public void agent3_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("agent3 enters username and password")
	public void agent3_enters_username_and_password() {

		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoagent");
		
	}

	@When("agent3 clicks on login")
	public void agent3_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}

	@Then("agent3 is navigated to home page")
	public void agent3_is_navigated_to_home_page() throws InterruptedException {

		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		Thread.sleep(2000);
			
	}

	@When("agent3 clicks on Hotel")
	public void agent3_clicks_on_hotel() {

		driver.findElement(By.xpath("//a[@title=\'hotels\']")).click();
		
	}

	@Then("agent3 is navigated to Hotels page")
	public void agent3_is_navigated_to_hotels_page() {

		driver.findElement(By.xpath("//h2[text()=\'SEARCH FOR BEST HOTELS\']")).isDisplayed();
		
	}

	@When("agent3 clicks to enter city and selects city")
	public void agent3_clicks_to_enter_city_and_selects_city() throws InterruptedException {

		//driver.findElement(By.xpath("//span[@id=\'select2-hotels_city-container\']")).click();
		//driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("Dub");
		//span[@id="select2-hotels_city-container"]
		driver.findElement(By.xpath("/html/body/section[1]/section/div/div/form/div/div/div[1]/div/div/div/span/span[1]/span/span[1]")).click();
		driver.findElement(By.xpath("/html/body/span/span/span[1]/input")).sendKeys("Mumb");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//li[text()='Mumbai,India']")).click();
		Thread.sleep(1000);
		/*
		driver.findElement(By.xpath("//input[@name='checkin']")).click();
		Thread.sleep(1000);
		//driver.findElement(By.xpath("//td[text()='28'])[1]")).click();
		
		driver.findElement(By.xpath("/html/body/div[5]/div[1]/table/tbody/tr[5]/td[2]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@name='checkout']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//td[text()='31'])[2]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//p[text()='Travellers ']")).click();
		Thread.sleep(1000);
		
		*/
	}

	@And("agent3 clicks on search icon")
	public void agent3_clicks_on_search_icon() throws InterruptedException {

		driver.findElement(By.xpath("//button[@id=\'submit\']")).click();
		Thread.sleep(1000);
		
	}

	@Then("agent3 is naigate to hotels in searched city page")
	public void agent3_is_naigate_to_hotels_in_searched_city_page() throws InterruptedException {

		driver.findElement(By.xpath("//h2[text()='Search Hotels in mumbai']")).isDisplayed();
		Thread.sleep(1000);
		driver.close();
		driver.quit();
	}
	
}
