package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierChangeBookingStatusAndVerifyCount {

	WebDriver driver=null;
	
	@Given("supplier3 browser is open")
	public void supplier3_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("supplier3 is on login page")
	public void supplier3_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/supplier");
		
	}

	@When("supplier3 enters username and password")
	public void supplier3_enters_username_and_password() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demosupplier");
		Thread.sleep(2000);
		
	}

	@And("supplier3 clicks on login")
	public void supplier3_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()=\'Login\']")).click();
		
	}

	@Then("supplier3 is navigated to dashboard")
	public void supplier3_is_navigated_to_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
			
	}

	@Then("supplier3 clicks on pending bookings and select to confirmed")
	public void supplier3_clicks_on_pending_bookings_and_select_to_confirmed() throws InterruptedException {
		
	    driver.findElement(By.xpath("//div[text()=\'Pending Bookings\']")).click();
	   
	    JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		Thread.sleep(2000);
	    
	    //Select se=new Select(driver.findElement(By.id("booking_status")));
	    Select se=new Select(driver.findElement(By.xpath("//select[@id=\'booking_status\']")));
	    se.selectByVisibleText("Confirmed");
	    Thread.sleep(2000);
	}

	@Then("supplier3 verify count in dashboard")
	public void supplier3_verify_count_in_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Dashboard\']")).click();
		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		driver.findElement(By.xpath("//div[text()=\'Confrimed Bookings\']")).click();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
	}
	
}
