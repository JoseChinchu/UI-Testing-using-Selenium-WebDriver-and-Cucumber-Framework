package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SupplierLogin {

	WebDriver driver=null;
	
	@Given("supplier browser is open")
	public void supplier_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}
	
	@And("supplier is on login page")
	public void supplier_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/supplier");
		
	}

	@When("supplier enters supplier@phptravels.com and demosupplier")
	public void supplier_enters_supplier_phptravels_com_and_demosupplier() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demosupplier");
		Thread.sleep(2000);
		
	}

	@When("supplier clicks on login")
	public void supplier_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()=\'Login\']")).click();
		
	}

	@Then("supplier is navigated to dashboard")
	public void supplier_is_navigated_to_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("supplier enters supplier@phptravels.com and abc1")
	public void supplier_enters_supplier_phptravels_com_and_abc1() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("supplier@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("abc1");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("supplier enters supplier and demosupplier")
	public void supplier_enters_supplier_and_demosupplier() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("supplier");
		driver.findElement(By.name("password")).sendKeys("demosupplier");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("supplier enters {int} and abc")
	public void supplier_enters_and_abc(Integer int1) throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("123");
		driver.findElement(By.name("password")).sendKeys("demosupplier");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}
	
}
