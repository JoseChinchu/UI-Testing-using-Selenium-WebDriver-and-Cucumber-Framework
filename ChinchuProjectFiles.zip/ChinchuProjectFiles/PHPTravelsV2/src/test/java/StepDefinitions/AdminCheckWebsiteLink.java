package StepDefinitions;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AdminCheckWebsiteLink {

	WebDriver driver=null;
	
	@Given("admin4 browser is open")
	public void admin4_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("admin4 is on login page")
	public void admin4_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/admin");
		
	}

	@When("admin4 enters username and password")
	public void admin4_enters_username_and_password() throws InterruptedException {

		driver.findElement(By.name("email")).sendKeys("admin@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoadmin");
		Thread.sleep(2000);
		
	}

	@And("admin4 clicks on login")
	public void admin4_clicks_on_login() {

		driver.findElement(By.xpath("//button[@type=\'submit\' and @class=\'btn btn-primary btn-block ladda-button fadeIn animated mdc-ripple-upgraded\']")).click();
		
	}

	@Then("admin4 is navigated to dashboard")
	public void admin4_is_navigated_to_dashboard() throws InterruptedException {

		driver.findElement(By.xpath("//div[text()=\'Sales overview & summary\']")).isDisplayed();
		Thread.sleep(2000);
		
	}

	@When("admin4 clicks on website link")
	public void admin4_clicks_on_website_link() throws InterruptedException {

		driver.findElement(By.xpath("//a[text()=\'Website\']")).click();
		Thread.sleep(2000);
		
	}

	@Then("admin4 is navigated to another page")
	public void admin4_is_navigated_to_another_page() throws InterruptedException {

		ArrayList<String> tabs= new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(1));
		
		driver.findElement(By.xpath("//a[text()=\"Last minute deals\" and @href=\"offers\"]")).isDisplayed();
		Thread.sleep(2000);
		
		driver.close();
		driver.switchTo().window(tabs.get(0));
		Thread.sleep(2000);
		driver.quit();
				
	}
	
}
