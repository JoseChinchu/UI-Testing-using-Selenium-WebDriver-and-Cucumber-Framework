package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentUSD2INR {

	WebDriver driver=null;
	
	@Given("agent4 browser is open")
	public void agent4_browser_is_open() {

		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("agent4 is on login page")
	public void agent4_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("agent4 enters username and password")
	public void agent4_enters_username_and_password() {

		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoagent");
		
	}

	@And("agent4 clicks on login")
	public void agent4_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}

	@Then("agent4 is navigated to home page")
	public void agent4_is_navigated_to_home_page() throws InterruptedException {

		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		Thread.sleep(2000);
			
	}

	@When("agent4 clicks on currency dropdown and select INR")
	public void agent4_clicks_on_currency_dropdown_and_select_inr() throws InterruptedException {
	    
		driver.findElement(By.id("currency")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[text()=' INR']")).click();
		Thread.sleep(2000);
	}

	@Then("agent4 is navigated to INR updated page")
	public void agent4_is_navigated_to_inr_updated_page() {
		
		driver.close();
		driver.quit();
		
	}

	
}
