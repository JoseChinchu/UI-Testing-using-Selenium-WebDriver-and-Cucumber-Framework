package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerUpdateAddressSteps {
	
	WebDriver driver=null;
	
	@Given("Browser opened by user3")
	public void browser_opened_by_user3() {
		
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("user3 is on the login page")
	public void user3_is_on_the_login_page() throws InterruptedException {

		driver.navigate().to("https://phptravels.net/login");
		Thread.sleep(2000);
		
		for (String winhandle: driver.getWindowHandles()) {
		    driver.switchTo().window(winhandle);
		    System.out.println("Window Switch");        
		    Thread.sleep(2000);
		    driver.findElement(By.id("cookie_stop")).click();
		}
	}

	@When("user3 enter username and password")
	public void user3_enter_username_and_password() {
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demouser");
		
	}

	@When("user3 clicks on login button")
	public void user3_clicks_on_login_button() {

		driver.findElement(By.xpath("//span[text()='Login']")).click();
		
	}

	@Then("user3 navigated to home page")
	public void user3_navigated_to_home_page() {
		
		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		
	}

	@Then("user3 clicks on My Profile")
	public void user3_clicks_on_my_profile() {
		
		driver.findElement(By.xpath("//a[@href=\'https://phptravels.net/account/profile\' and @class=\' waves-effect\']")).click();
		
	}
	
	@Then("user3 clears existing data and enter updated address")
	public void user3_clears_existing_data_and_enter_updated_address() {

		
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement updateprofilebtn=driver.findElement(By.xpath("//button[text()=\'Update Profile\']"));
		js.executeScript("arguments[0].scrollIntoView();", updateprofilebtn);
		
		//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		/*
		Select drpCountry= new Select(driver.findElement(By.xpath("//select[@id=\'select2-from_country-container\']")));
		drpCountry.selectByVisibleText("India");
		*/
		WebElement state=driver.findElement(By.xpath("//input[@name=\'state\']"));
		state.clear();
		state.sendKeys("Kerala");
		
		WebElement city=driver.findElement(By.xpath("//input[@name=\'city\']"));
		city.clear();
		city.sendKeys("Kottayam");
		
		WebElement zip=driver.findElement(By.xpath("//input[@name=\'zip\']"));
		zip.clear();
		zip.sendKeys("686562");
		
		WebElement addrs1=driver.findElement(By.xpath("//input[@name=\'address1\']"));
		addrs1.clear();
		addrs1.sendKeys("SKMangalam");
		
		WebElement addrs2=driver.findElement(By.xpath("//input[@name=\'address2\']"));
		addrs2.clear();
		addrs2.sendKeys("Athirampuzha");
		
		
					
	}

	@Then("user3 clicks on Update Profile button")
	public void user3_clicks_on_update_profile_button() throws InterruptedException {
	    
	/*	JavascriptExecutor js1 = (JavascriptExecutor) driver;
		js1.executeScript("window.scrollBy(5000, 0)", "");
	*/	
		//WebElement downarrow=driver.findElement(By.xpath("//div[@id=\'back-to-top\']"));
		//js1.executeScript("arguments[0].scrollIntoView();", downarrow);
		//Thread.sleep(1000);
		//js1.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		
		driver.findElement(By.xpath("//button[text()=\'Update Profile\']")).click();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}
}
