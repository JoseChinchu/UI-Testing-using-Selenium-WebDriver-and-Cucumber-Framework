package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentTestLinks2 {

	WebDriver driver=null;
	
	@Given("agent2 browser is open")
	public void agent2_browser_is_open() {
		
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
				
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("agent2 is on login page")
	public void agent2_is_on_login_page() {

		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("agent2 enters username and password")
	public void agent2_enters_username_and_password() {

		driver.findElement(By.name("email")).sendKeys("agent@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demoagent");
			
	}

	@When("agent2 clicks on login")
	public void agent2_clicks_on_login() {

		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}

	@Then("agent2 is navigated to home page")
	public void agent2_is_navigated_to_home_page() throws InterruptedException {

		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		Thread.sleep(2000);
				
	}
/*
	@When("agent2 clicks on Home icon")
	public void agent2_clicks_on_home_icon() {
	
		driver.close();
	}
	
	@Then("agent2 is navigated to Home page")
	public void agent2_is_navigated_to_Home_page() {
		driver.close();
	}
*/
	@When("agent2 clicks on Hotel")
	public void agent2_clicks_on_hotel() {

		driver.findElement(By.xpath("//a[@title=\'hotels\']")).click();
		
	}

	@Then("agent2 is navigated to Hotels page")
	public void agent2_is_navigated_to_hotels_page() {

		driver.findElement(By.xpath("//h2[text()=\'SEARCH FOR BEST HOTELS\']")).isDisplayed();
		
	}
	
	@When("agent2 clicks on Flights")
	public void agent2_clicks_on_flights() {

		driver.findElement(By.xpath("//a[@title=\'flights\']")).click();
		
	}

	@Then("agent2 is navigated to Flights page")
	public void agent2_is_navigated_to_flights_page() {
		
		driver.findElement(By.xpath("//h2[text()=\'SEARCH FOR BEST FLIGHTS\']")).isDisplayed();
	}
	
	@When("agent2 clicks on Tours")
	public void agent2_clicks_on_tours() {

		driver.findElement(By.xpath("//a[@title=\'tours\']")).click();
		
	}

	@Then("agent2 is navigated to Tours page")
	public void agent2_is_navigated_to_tours_page() {

		driver.findElement(By.xpath("//h2[text()=\'Find the best tours packages\']")).isDisplayed();
		
	}
	
	@When("agent2 clicks on Visa")
	public void agent2_clicks_on_visa() {
		
		driver.findElement(By.xpath("//a[@title=\'visa\']")).click();
		
	}

	@Then("agent2 is navigated to Visa page")
	public void agent2_is_navigated_to_visa_page() {

		driver.findElement(By.xpath("//h2[text()=\'Submit Your Visa Today!\']")).isDisplayed();
		
	}
	
	@When("agent2 clicks on Blog")
	public void agent2_clicks_on_blog() {

		driver.findElement(By.xpath("//a[@title=\'blog\']")).click();
		
	}

	@Then("agent2 is navigated to Blog page")
	public void agent2_is_navigated_to_blog_page() {

		driver.findElement(By.xpath("//h2[text()=\'PHPTRAVELS Blog\']")).isDisplayed();
		
	}
	
	@When("agent2 clicks on Offers")
	public void agent2_clicks_on_offers() {

		driver.findElement(By.xpath("//a[@title=\'offers\']")).click();
		
	}
	
	@Then("agent2 is navigated to Offers page")
	public void agent2_is_navigated_to_offers_page() {

		driver.findElement(By.xpath("//h2[text()=\'PHPTRAVELS Offers\']")).isDisplayed();
		driver.close();
		driver.quit();
		
	}
	
}
