package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CustomerLoginDemoSteps2 {

	WebDriver driver=null;
	
	@Given("browser is open")                  
	public void browser_is_open() {
	
		System.out.println("Inside step-Browser is open");
		String projectPath=System.getProperty("user.dir");
		System.out.println("Project path is: "+projectPath);
		//System.setProperty("webdriver.chrome.driver", projectPath+"/src/test/resources/drivers/chromedriver.exe");
		
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.manage().timeouts().implicitlyWait(40,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40,TimeUnit.SECONDS);
		
	}

	@And("user is on login page")
	public void user_is_on_login_page() {
		
		driver.navigate().to("https://phptravels.net/login");
		
	}

	@When("user enters user@phptravels.com and demouser")
	public void user_enters_user_phptravels_com_and_demouser() throws InterruptedException {
	    
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("demouser");
		Thread.sleep(2000);
		
	}
	
	@And("user clicks on login")
	public void user_clicks_on_login() {
		
		driver.findElement(By.xpath("//span[text()='Login']")).click();
	    
	}
	
	@Then("user is navigated to home page")
	public void user_is_navigated_to_home_page() throws InterruptedException {
		
		driver.findElement(By.xpath("//span[text()=\'Welcome Back\']")).isDisplayed();
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("user enters user@phptravels.com and abc1")
	public void user_enters_user_phptravels_com_and_abc1() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("user@phptravels.com");
		driver.findElement(By.name("password")).sendKeys("abc1");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("user enters user and demouser")
	public void user_enters_user_and_demouser() throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("user");
		driver.findElement(By.name("password")).sendKeys("demouser");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

	@When("user enters {int} and abc")
	public void user_enters_and_abc(Integer int1) throws InterruptedException {
		
		driver.findElement(By.name("email")).sendKeys("123");
		driver.findElement(By.name("password")).sendKeys("demouser");
		Thread.sleep(2000);
		driver.close();
		driver.quit();
		
	}

}
